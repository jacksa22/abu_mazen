import React, { useState } from 'react';
import { Menu, MapPin, Clock, Phone, Facebook, Instagram, X } from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-white/90 backdrop-blur-md shadow-md">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-20">
            <h1 className="text-2xl font-bold text-yellow-600">أبو مازن</h1>
            <div className="hidden md:flex space-x-8 space-x-reverse">
              <NavLink href="#home">الرئيسية</NavLink>
              <NavLink href="#menu">قائمة الطعام</NavLink>
              <NavLink href="#location">موقعنا</NavLink>
              <NavLink href="#contact">اتصل بنا</NavLink>
            </div>
            <button 
              className="md:hidden text-gray-600 hover:text-yellow-600 transition"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
              <MobileNavLink href="#home" onClick={() => setIsMenuOpen(false)}>الرئيسية</MobileNavLink>
              <MobileNavLink href="#menu" onClick={() => setIsMenuOpen(false)}>قائمة الطعام</MobileNavLink>
              <MobileNavLink href="#location" onClick={() => setIsMenuOpen(false)}>موقعنا</MobileNavLink>
              <MobileNavLink href="#contact" onClick={() => setIsMenuOpen(false)}>اتصل بنا</MobileNavLink>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <div 
        id="home"
        className="h-screen bg-cover bg-center relative"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1615996001375-c7ef13294436?auto=format&fit=crop&q=80")',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 to-black/50">
          <div className="container mx-auto px-4 h-full flex flex-col justify-center items-center text-center">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 animate-fade-in">مطعم أبو مازن</h1>
            <p className="text-xl md:text-3xl text-yellow-400 mb-8 animate-fade-in-delay">ألذ الوجبات السريعة في الهرم</p>
            <a 
              href="#menu" 
              className="bg-yellow-500 text-black px-8 py-4 rounded-full text-xl font-semibold hover:bg-yellow-400 transition duration-300 transform hover:scale-105 animate-bounce-slow"
            >
              اكتشف قائمة الطعام
            </a>
          </div>
        </div>
      </div>

      {/* Menu Section */}
      <div id="menu" className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-4">قائمة الطعام</h2>
          <p className="text-gray-600 text-center mb-16 text-lg">أشهى المأكولات الشرقية والغربية</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <MenuItem 
              title="ساندوتش شاورما دجاج"
              description="شاورما دجاج طازجة مع صوص خاص"
              price="48 جنيه"
              image="https://images.unsplash.com/photo-1529006557810-274b9b2fc783?auto=format&fit=crop&q=80"
            />
            <MenuItem 
              title="ساندوتش بطاطس"
              description="بطاطس مقلية مع مايونيز وكاتشب"
              price="15 جنيه"
              image="https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?auto=format&fit=crop&q=80"
            />
            <MenuItem 
              title="كريب بطاطس"
              description="كريب محشو بالبطاطس والجبنة"
              price="35 جنيه"
              image="https://images.unsplash.com/photo-1528699633788-424224dc89b5?auto=format&fit=crop&q=80"
            />
            <MenuItem 
              title="كريب فراخ"
              description="كريب محشو بالفراخ والخضار"
              price="65 جنيه"
              image="https://images.unsplash.com/photo-1604147495798-57beb5d6af73?auto=format&fit=crop&q=80"
            />
            <MenuItem 
              title="وجبة زنجر"
              description="دجاج مقرمش مع بطاطس وكولسلو"
              price="85 جنيه"
              image="https://images.unsplash.com/photo-1513185158878-8d8c2a2a3da3?auto=format&fit=crop&q=80"
            />
            <MenuItem 
              title="وجبة شاورما دجاج"
              description="شاورما دجاج مع أرز وسلطة"
              price="75 جنيه"
              image="https://images.unsplash.com/photo-1529006557810-274b9b2fc783?auto=format&fit=crop&q=80"
            />
            <MenuItem 
              title="وجبة برجر لحم"
              description="برجر لحم مع بطاطس ومشروب"
              price="90 جنيه"
              image="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&q=80"
            />
            <MenuItem 
              title="وجبة ستربس"
              description="قطع دجاج مقرمشة مع بطاطس"
              price="80 جنيه"
              image="https://images.unsplash.com/photo-1619881590738-a111d176d906?auto=format&fit=crop&q=80"
            />
            <MenuItem 
              title="وجبة مكس جريل"
              description="تشكيلة من المشويات مع الأرز"
              price="120 جنيه"
              image="https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80"
            />
          </div>
        </div>
      </div>

      {/* Location Section */}
      <div id="location" className="py-24 bg-gray-100">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">موقعنا</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <InfoCard 
              icon={<MapPin className="w-8 h-8" />}
              title="العنوان"
              content="شارع المجزر الآلي، الهرم، الجيزة"
            />
            <InfoCard 
              icon={<Clock className="w-8 h-8" />}
              title="ساعات العمل"
              content="متاح 24 ساعة"
            />
            <InfoCard 
              icon={<Phone className="w-8 h-8" />}
              title="اتصل بنا"
              content="٠١١٠٠٣٣٣٧٩٩ - ٠١٢١٢٦٨٨٨٩٤ - ٠١٠٨٠٢٩٩١٠"
            />
          </div>
        </div>
      </div>

      {/* Contact Section */}
      <div id="contact" className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">تواصل معنا</h2>
          <div className="max-w-lg mx-auto">
            <form className="space-y-6">
              <input
                type="text"
                placeholder="الاسم"
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-yellow-500"
              />
              <input
                type="email"
                placeholder="البريد الإلكتروني"
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-yellow-500"
              />
              <textarea
                placeholder="رسالتك"
                rows={5}
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-yellow-500"
              />
              <button
                type="submit"
                className="w-full bg-yellow-500 text-black py-3 rounded-lg font-semibold hover:bg-yellow-400 transition duration-300"
              >
                إرسال
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="text-2xl font-bold mb-4">مطعم أبو مازن</h3>
              <p className="text-gray-400">نقدم أشهى الوجبات السريعة في الهرم</p>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">روابط سريعة</h3>
              <ul className="space-y-2">
                <li><a href="#home" className="text-gray-400 hover:text-yellow-500 transition">الرئيسية</a></li>
                <li><a href="#menu" className="text-gray-400 hover:text-yellow-500 transition">قائمة الطعام</a></li>
                <li><a href="#location" className="text-gray-400 hover:text-yellow-500 transition">موقعنا</a></li>
                <li><a href="#contact" className="text-gray-400 hover:text-yellow-500 transition">اتصل بنا</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">تابعنا</h3>
              <div className="flex space-x-4 space-x-reverse">
                <a href="#" className="text-gray-400 hover:text-yellow-500 transition">
                  <Facebook className="w-6 h-6" />
                </a>
                <a href="#" className="text-gray-400 hover:text-yellow-500 transition">
                  <Instagram className="w-6 h-6" />
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8">
            <p className="text-center text-gray-400">© 2024 مطعم أبو مازن. جميع الحقوق محفوظة</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function NavLink({ href, children }) {
  return (
    <a 
      href={href} 
      className="text-gray-700 hover:text-yellow-600 transition duration-300"
    >
      {children}
    </a>
  );
}

function MobileNavLink({ href, children, onClick }) {
  return (
    <a 
      href={href}
      onClick={onClick}
      className="block text-gray-700 hover:text-yellow-600 transition duration-300 text-lg"
    >
      {children}
    </a>
  );
}

function MenuItem({ title, description, price, image }) {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition duration-300">
      <div className="relative">
        <img src={image} alt={title} className="w-full h-56 object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300" />
      </div>
      <div className="p-6">
        <h3 className="text-xl font-bold mb-2">{title}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        <p className="text-yellow-500 font-bold text-lg">{price}</p>
      </div>
    </div>
  );
}

function InfoCard({ icon, title, content }) {
  return (
    <div className="text-center p-8 bg-white rounded-xl shadow-lg hover:shadow-xl transition duration-300">
      <div className="flex justify-center mb-6 text-yellow-500">
        {icon}
      </div>
      <h3 className="text-2xl font-bold mb-4">{title}</h3>
      <p className="text-gray-600 text-lg">{content}</p>
    </div>
  );
}

export default App;